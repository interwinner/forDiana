using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices.WindowsRuntime;
using UnityEngine;
using System.IO;

[System.Serializable]
public class Options
{
    public string text;
    public int correct;
}

[System.Serializable]
public class Question
{
    public string question_text;
    public string question_image;
    public string question_audio;
    public string explanation;
    public Options[] options;
}

[System.Serializable]
public class Questions {
    public Question [] questions;
}

[System.Serializable]
public class Report {
    public float duration;
    public int grade;
    public int errors;

    public string SaveToString()
    {
        return JsonUtility.ToJson(this);
    }
}

public class JsonProcessor : MonoBehaviour
{

    private TextAsset jsonFile;

    public static Questions questionInJson;

    void Start()
    {
        readFile();
    }

    public void readFile()
    {

        jsonFile = Resources.Load<TextAsset>("Input") as TextAsset;
        questionInJson = JsonUtility.FromJson<Questions>(jsonFile.text);

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
