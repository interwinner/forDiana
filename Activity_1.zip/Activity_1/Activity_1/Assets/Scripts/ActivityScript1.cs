using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using TMPro;
using UnityEngine;
using UnityEngine.Device;
using UnityEngine.Networking;
using UnityEngine.Rendering;
using UnityEngine.UI;

using static System.Net.WebRequestMethods;

public class ActivityScript1 : MonoBehaviour
{
    
    public TextMeshProUGUI QuestionTxt, OptTxt1, OptTxt2, OptTxt3, ErrorTxt;
    public Transform Opt1, Opt2, Opt3;
    public Transform ErrorMsg;
    public Transform QObj;
    static float[] OptionPosY = { 30.0f, -120.0f, -270.0f };

    private int RightIndex;
    private int CurrentQuestionIndex;
    private int RightCount;
    private int WrongCount;
    private float PassedTime;

void Start()
    {
        CurrentQuestionIndex = 0;
        JsonProcessForText();
        ArrangeInRandom();
        ////////////...........Json should  Modifyed...........................
        string imageurl, audiourl;
        imageurl = ImageUrlToJson();
        audiourl = AudioUrlToJson();
        NetworkProcessForImage(imageurl, QObj);
        NetworkProcessForAudio(audiourl, transform);
        ////////////...........Json should  Modifyed...........................
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OnWorongOptionClick() {
        ErrorMsg.gameObject.SetActive(true);
        WrongCount++;
        CurrentQuestionIndex++;
        Opt1.GetComponent<Button>().interactable=false;
        Opt2.GetComponent<Button>().interactable = false;
        Opt3.GetComponent<Button>().interactable = false;
        QObj.GetComponent<Button>().interactable = true;

        NetworkProcessForAudio("https://media.edutechnoz.com/apps/fx/wrong-0.wav", transform);
    }
    public void OnRightOptionClick()
    {
        RightCount++;
        CurrentQuestionIndex++;
        Opt1.GetComponent<Button>().interactable = false;
        Opt2.GetComponent<Button>().interactable = false;
        Opt3.GetComponent<Button>().interactable = false;
        QObj.GetComponent<Button>().interactable = true;

        NetworkProcessForAudio("https://media.edutechnoz.com/apps/fx/correct-0.mp3", transform);
    }
    void toNextQuestion()
    {
        if (CurrentQuestionIndex == JsonProcessor.questionInJson.questions.Length) { 
            CurrentQuestionIndex = 0; }
        ArrangeInRandom();
        JsonProcessForText();
        ////////////...........Json should  Modifyed...........................
        string imageurl, audiourl;
        imageurl = ImageUrlToJson();
        audiourl = AudioUrlToJson();
        NetworkProcessForImage(imageurl, QObj);
        NetworkProcessForAudio(audiourl, transform);
        ////////////...........Json should  Modifyed...........................
    }
    public void OnQuestionClick() {
        toNextQuestion();
        ErrorMsg.gameObject.SetActive(false);
        QObj.GetComponent<Button>().interactable = false;
        Opt1.GetComponent<Button>().interactable = true;
        Opt2.GetComponent<Button>().interactable = true;
        Opt3.GetComponent<Button>().interactable = true;
    }

    public void OnExit()
    {
        Report report;
        report = new Report();
        report.duration = Time.frameCount * Time.fixedDeltaTime / 10.0f;
        report.grade = RightCount;
        report.errors = WrongCount;
        string jsonString = report.SaveToString();
        string saveFile = "E:/report.json";
        FileStream fileStream = new FileStream(saveFile, FileMode.Create);
        using (StreamWriter writer = new StreamWriter(fileStream))
        {
            writer.Write(jsonString);
        }
        System.IO.File.WriteAllText(saveFile, jsonString);
        UnityEngine.Application.Quit();
    }

    void JsonProcessForText()
    {
        QuestionTxt.text = JsonProcessor.questionInJson.questions[CurrentQuestionIndex].question_text;
        OptTxt1.text = JsonProcessor.questionInJson.questions[CurrentQuestionIndex].options[0].text;
        OptTxt2.text = JsonProcessor.questionInJson.questions[CurrentQuestionIndex].options[1].text;
        OptTxt3.text = JsonProcessor.questionInJson.questions[CurrentQuestionIndex].options[2].text;
        ErrorTxt.text = JsonProcessor.questionInJson.questions[CurrentQuestionIndex].explanation;

    }

    string ImageUrlToJson()
    {
       return JsonProcessor.questionInJson.questions[CurrentQuestionIndex].question_image;
    }

    string AudioUrlToJson()
    {
        return JsonProcessor.questionInJson.questions[CurrentQuestionIndex].question_audio;
    }

    void ArrangeInRandom()
    {
        ErrorMsg.gameObject.SetActive(false);
        RightIndex = UnityEngine.Random.Range(0, 3);
        int index1 = 0, index2 = 0;
        while (RightIndex == index1 || RightIndex == index2 || index1 == index2)
        {
            index1 = UnityEngine.Random.Range(0, 3);
            index2 = UnityEngine.Random.Range(0, 3);
        }
        Opt1.localPosition = Vector3.zero + new Vector3(0, OptionPosY[index1], 0);
        Opt2.localPosition = Vector3.zero + new Vector3(0, OptionPosY[index2], 0);
        Opt3.localPosition = Vector3.zero + new Vector3(0, OptionPosY[RightIndex], 0);

        QObj.GetComponent<Button>().interactable = false;
    }
    void NetworkProcessForImage(string url, Transform trans)
    {
        transform.GetComponent<NetWorkManager>().DownloadImage(url, trans);
    }

    void NetworkProcessForAudio(string url, Transform trans)
    {
        transform.GetComponent<NetWorkManager>().DownloadSound(url, trans);
    }



}
