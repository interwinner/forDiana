
using System.IO;
using TMPro;
using UnityEngine;

using static System.Net.WebRequestMethods;

public class ActivityScript1 : MonoBehaviour
{
    
    public TextMeshProUGUI QuestionTxt,ErrorTxt;
    public Transform[] Opt = new Transform[5];
    public Transform[] Opt_M = new Transform[5];
    public Transform ErrorMsg;
    static float[] OptionPosY = { 280.0f, 130.0f, -20.0f, -170.0f, -320.0f };

    private int RightCount = 0;
    private int WrongCount = 0;
    private string ClickedName;
    private float PassedTime;

    public bool CanDetermine;
    public int OptionClickCount;
    public int PrevIndex;
    public Transform preTransform;

    void Start()
    {
        JsonProcessForText(0);
        ArrangeInRandom();
        CanDetermine = false;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void OnWorongOptionClick() {

        ErrorMsg.gameObject.SetActive(true);
        WrongCount++;

        NetworkProcessForAudio("https://media.edutechnoz.com/apps/fx/correct-0.mp3", transform);
    }
    public void OnRightOptionClick()
    {
        RightCount++;
        NetworkProcessForAudio("https://media.edutechnoz.com/apps/fx/wrong-0.wav", transform);
        ErrorMsg.gameObject.SetActive(false);
    }
    public void OnQuestionClick() {
        ErrorMsg.gameObject.SetActive(false);
    }

    public void OnExit()
    {
        Report report;
        report = new Report();
        report.duration = Time.frameCount * Time.fixedDeltaTime / 10.0f;
        report.grade = RightCount;
        report.errors = WrongCount;
        string jsonString = report.SaveToString();
        string saveFile = "E:/report.json";
        FileStream fileStream = new FileStream(saveFile, FileMode.Create);
        using (StreamWriter writer = new StreamWriter(fileStream))
        {
            writer.Write(jsonString);
        }
        System.IO.File.WriteAllText(saveFile, jsonString);
        UnityEngine.Application.Quit();
    }

    void JsonProcessForText(int index)
    {
        QuestionTxt.text = JsonProcessor.questionInJson.question_text;
        ErrorTxt.text = JsonProcessor.questionInJson.options[index].explanation;

    }

    void ArrangeInRandom()
    {
        int[] IdA = new int[5];
        int[] IdB = new int[5];
        IdA[0] = UnityEngine.Random.Range(0,5);
        IdB[0] = UnityEngine.Random.Range(0, 5);
        int j = 0;
        for (int i = 1;i<5;i++) {
            IdA[i] = UnityEngine.Random.Range(0, 5);
            IdB[i] = UnityEngine.Random.Range(0, 5);
            j = 0;
            while(j<i) {
                if (IdA[i] == IdA[j])
                {
                    IdA[i] = UnityEngine.Random.Range (0, 5);
                    j = -1 ;
                }
                j++;

            }
            j = 0;
            while (j<i)
            {
                
                if (IdB[i] == IdB[j])
                {
                    IdB[i] = UnityEngine.Random.Range(0, 5);
                    j = -1;
                }
                j++;
            }
        }
        for(int i = 0; i < 5; i++)
        {
            
            Opt[i].localPosition = Vector3.zero + new Vector3(-200 , OptionPosY[IdA[i]], 0);
            Opt_M[i].localPosition = Vector3.zero + new Vector3(200, OptionPosY[IdB[i]], 0);
            string imageurlA, imageurlB;
            imageurlA = ImageUrlToJsonForA(i);
            NetworkProcessForImage(imageurlA, Opt[i]);
            imageurlB = ImageUrlToJsonForB(i);
            NetworkProcessForImage(imageurlB, Opt_M[i]);
        }

        ErrorMsg.gameObject.SetActive(false);
    }

    string ImageUrlToJsonForA(int index)
    {
        return JsonProcessor.questionInJson.options[index].matchAimage;
    }

    string ImageUrlToJsonForB(int index)
    {
        return JsonProcessor.questionInJson.options[index].matchBimage;
    }

    void NetworkProcessForImage(string url, Transform trans)
    {
        transform.GetComponent<NetWorkManager>().DownloadImage(url, trans);
    }

    void NetworkProcessForAudio(string url, Transform trans)
    {
        transform.GetComponent<NetWorkManager>().DownloadSound(url, trans);
    }

}
