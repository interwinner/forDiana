
using UnityEngine;

[System.Serializable]
public class Options
{
    public string matchAtext;
    public string matchAimage;
    public string matchAaudio;
    public string matchBtext;
    public string matchBimage;
    public string matchBaudio;
    public string explanation;

}

[System.Serializable]
public class Question
{
    public string question_text;
    public string question_image;
    public string question_audio;
    public Options[] options;
}

[System.Serializable]
public class Report {
    public float duration;
    public int grade;
    public int errors;

    public string SaveToString()
    {
        return JsonUtility.ToJson(this);
    }
}

public class JsonProcessor : MonoBehaviour
{

    private TextAsset jsonFile;

    public static Question questionInJson;

    void Start()
    {
        readFile();
    }

    public void readFile()
    {

        jsonFile = Resources.Load<TextAsset>("Input") as TextAsset;
        questionInJson = JsonUtility.FromJson<Question>(jsonFile.text);

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
