
using UnityEngine;
using UnityEngine.EventSystems;
public class Option : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
{
    public int Index;

    public Transform Panel;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OnPointerDown(PointerEventData data)
    {
        Panel.GetComponent<ActivityScript1>().OptionClickCount++;
        if (Panel.GetComponent<ActivityScript1>().OptionClickCount == 2)
        {
            Panel.GetComponent<ActivityScript1>().CanDetermine= true;
            Panel.GetComponent<ActivityScript1>().OptionClickCount = 0;
        }
        for (int i = 0; i < 5; i++) { 
            if(transform.parent.GetChild(i) == transform) {
                Index= i;
            }
        }

        if (Panel.GetComponent<ActivityScript1>().CanDetermine) { 
            if(Index == Panel.GetComponent<ActivityScript1>().PrevIndex && Panel.GetComponent<ActivityScript1>().preTransform.parent != transform.parent)
            {
                //.......right......
                Panel.GetComponent<ActivityScript1>().OnRightOptionClick();
                Debug.Log("RIGHT");
            }
            else
            {
                //.......error........
                Panel.GetComponent<ActivityScript1>().OnWorongOptionClick();
                Debug.Log("FALSE");
            }
            Panel.GetComponent<ActivityScript1>().CanDetermine= false;
        }
        else
        {
            Panel.GetComponent<ActivityScript1>().preTransform = transform;
            Panel.GetComponent<ActivityScript1>().PrevIndex = Index;
        }

    }

    public void OnPointerUp(PointerEventData data)
    {
        

    }
}
